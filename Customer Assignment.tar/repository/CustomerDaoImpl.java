package com.ltimindtree.demoproject.repository;

import java.util.ArrayList;

import com.ltimindtree.demoproject.model.Customer;

public class CustomerDaoImpl implements CustomerDao {
    ArrayList<Customer> list=new ArrayList<>();
    Customer temp=new Customer();

    @Override
    public ArrayList<Customer> showCustomerList() {
        // TODO Auto-generated method stub
        return list ;
    }

    @Override
    public void addCustomer(Customer c) {
        // TODO Auto-generated method stub
        list.add(c);
        
    }

    @Override
    public Customer getById(int cusId) {
        // TODO Auto-generated method stub
        for(Customer c:list){
            if(c.getCusId()==cusId){
                temp=c;
            }
        }
        return temp;
    }

    @Override
    public void update(int cusId, Customer c) {
        // TODO Auto-generated method stub
        for(Customer p:list){
            if(p.getCusId()==cusId){
                list.set(cusId,c);
            }
        }
        System.out.println("Yes,your customer data updated:");
        
    }

    @Override
    public Customer deleteById(int cusId) {
        // TODO Auto-generated method stub
        for(Customer d:list){
            if(d.getCusId()==cusId){
                temp=d;
                list.remove(d);
            }
        }
        return temp;
    }
    
}
