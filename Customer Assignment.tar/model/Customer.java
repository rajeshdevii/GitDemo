package com.ltimindtree.demoproject.model;

public class Customer {
    private int cusId;
    private String cusName;
    private double cost;
    public Customer() {
    }
    public Customer(int cusId, String cusName, double cost) {
        this.cusId = cusId;
        this.cusName = cusName;
        this.cost = cost;
    }
    public int getCusId() {
        return cusId;
    }
    public void setCusId(int cusId) {
        this.cusId = cusId;
    }
    public String getCusName() {
        return cusName;
    }
    public void setCusName(String cusName) {
        this.cusName = cusName;
    }
    public double getCost() {
        return cost;
    }
    public void setCost(double cost) {
        this.cost = cost;
    }
    @Override
    public String toString() {
        return "Customer [cost=" + cost + ", cusId=" + cusId + ", cusName=" + cusName + "]";
    }
    
}
