package com.ltimindtree.demoproject.controller;

import java.util.ArrayList;

import com.ltimindtree.demoproject.model.Customer;
import com.ltimindtree.demoproject.service.CustomerServiceImpl;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    CustomerServiceImpl service =new CustomerServiceImpl();

@GetMapping("/show")
public ArrayList<Customer> showCustomer(){
    return service.showCustomerList();
}

@GetMapping("/ById/{pid}")
public Customer findById(@PathVariable("pid") int cusId){
    return service.getById(cusId);
}

@PostMapping("/add")
public void addCustomer(@RequestBody Customer c)
{
    service.addCustomer(c);
}
@PutMapping("/update/{pid}")
public void update(@PathVariable("pid") int cusId,@RequestBody Customer c) 
{
     service.update(cusId, c);
}
@DeleteMapping("/delete/{pid}")
public Customer deleteById(@PathVariable("pid")int cusId)
{
    return service.deleteById(cusId);
}
    
}

