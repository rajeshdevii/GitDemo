package com.ltimindtree.demoproject.service;

import java.util.ArrayList;

import com.ltimindtree.demoproject.model.Customer;
import com.ltimindtree.demoproject.repository.CustomerDaoImpl;

public class CustomerServiceImpl implements CustomerService {
    CustomerDaoImpl dao=new CustomerDaoImpl();
    @Override
    public ArrayList<Customer> showCustomerList() {
        // TODO Auto-generated method stub
        return dao.showCustomerList();
    }

    @Override
    public void addCustomer(Customer c) {
        // TODO Auto-generated method stub
        dao.addCustomer(c);
    }

    @Override
    public Customer getById(int cusId) {
        // TODO Auto-generated method stub
        return dao.getById(cusId);
    }

    @Override
    public void update(int cusId, Customer c) {
        // TODO Auto-generated method stub
        dao.update(cusId, c);
        
    }

    @Override
    public Customer deleteById(int cusId) {
        // TODO Auto-generated method stub
        return dao.deleteById(cusId);
    }
    
}

