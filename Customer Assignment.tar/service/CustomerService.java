package com.ltimindtree.demoproject.service;

import java.util.ArrayList;

import com.ltimindtree.demoproject.model.Customer;

public interface CustomerService {
    public ArrayList<Customer> showCustomerList();
    public void addCustomer(Customer c);
    public Customer getById(int cusId);
    public void update(int cusId,Customer c);
    public Customer deleteById(int cusId);
}